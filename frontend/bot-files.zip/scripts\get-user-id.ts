/**
 * Helper script to get your Magic Link user ID (DID)
 * Run this after logging in to get your user ID for the bot
 */

import { ConvexHttpClient } from 'convex/browser';
import * as dotenv from 'dotenv';
import * as path from 'path';

// Load .env.local
dotenv.config({ path: path.join(__dirname, '..', '.env.local') });

const convex = new ConvexHttpClient(process.env.NEXT_PUBLIC_CONVEX_URL || '');

async function getUserId() {
  console.log('\n=== Get Your Magic Link User ID ===\n');
  
  // Get all users
  const users = await convex.query('users:getAllUsers' as any);
  
  if (!users || users.length === 0) {
    console.log('No users found. Please sign up first at http://localhost:3000');
    return;
  }
  
  console.log('Available users:\n');
  users.forEach((user: any, index: number) => {
    console.log(`${index + 1}. ${user.email || 'No email'}`);
    console.log(`   User ID: ${user.userId}`);
    console.log(`   Balance: ${user.usdcBalance || '0'} USDC`);
    console.log('');
  });
  
  console.log('\nTo run the market maker bot, use:');
  console.log('\nPowerShell:');
  console.log('$env:MM_USER_ID="<USER_ID_FROM_ABOVE>"');
  console.log('npx ts-node --project tsconfig.json scripts/market-maker-bot-v2.ts');
  
  console.log('\nBash:');
  console.log('MM_USER_ID=<USER_ID_FROM_ABOVE> npx ts-node --project tsconfig.json scripts/market-maker-bot-v2.ts');
}

getUserId().catch(console.error);
