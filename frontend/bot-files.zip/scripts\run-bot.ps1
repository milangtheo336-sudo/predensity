# PowerShell script to run the market maker bot
# Usage: .\scripts\run-bot.ps1

Write-Host "`n=== Predensity Market Maker Bot ===" -ForegroundColor Cyan
Write-Host ""

# Load environment variables from .env.local
if (Test-Path ".env.local") {
    Get-Content ".env.local" | ForEach-Object {
        if ($_ -match '^([^#][^=]+)=(.*)$') {
            $name = $matches[1].Trim()
            $value = $matches[2].Trim()
            [Environment]::SetEnvironmentVariable($name, $value, "Process")
        }
    }
    Write-Host "Loaded environment from .env.local" -ForegroundColor Green
} else {
    Write-Host "Warning: .env.local not found" -ForegroundColor Yellow
}

# Check if user ID is provided
if (-not $env:MM_USER_ID) {
    Write-Host ""
    Write-Host "ERROR: MM_USER_ID not set" -ForegroundColor Red
    Write-Host ""
    Write-Host "To get your user ID:" -ForegroundColor Yellow
    Write-Host "1. Sign in at http://localhost:3000" -ForegroundColor White
    Write-Host "2. Open browser console (F12)" -ForegroundColor White
    Write-Host "3. Run: localStorage.getItem('magic_user')" -ForegroundColor White
    Write-Host "4. Copy the 'issuer' value (starts with 'did:ethr:0x...')" -ForegroundColor White
    Write-Host ""
    Write-Host "Then run:" -ForegroundColor Yellow
    Write-Host '$env:MM_USER_ID="did:ethr:0x..."' -ForegroundColor White
    Write-Host ".\scripts\run-bot.ps1" -ForegroundColor White
    Write-Host ""
    exit 1
}

Write-Host "User ID: $env:MM_USER_ID" -ForegroundColor Cyan
Write-Host "Convex URL: $env:NEXT_PUBLIC_CONVEX_URL" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting market maker bot..." -ForegroundColor Green
Write-Host ""

# Run the bot
npx ts-node --project tsconfig.json scripts/market-maker-bot-v2.ts
